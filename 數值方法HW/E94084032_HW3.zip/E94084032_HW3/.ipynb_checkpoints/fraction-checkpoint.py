# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 00:06:18 2022

@author: KYLE
"""

import  math  
class Fraction(object):
    """
 User-defined ojbect to represent numeric fractions
 The top value, known as the numerator, can be any integer.
 The bottom value, called the denominator, can be any integer
greater than 0
    """

    def __init__(self,x,y):
        self.denominator=y #分母
        self.numerator=x   #分子
    
        if self.denominator<0:
            self.denominator= -self.denominator
            self.numerator=   -self.numerator
        
         
        
        
        

    def __add__(self,other):
        denominator_N=self.denominator*other.denominator
        numerator_N  =self.denominator*other.numerator + other.denominator*self.numerator
        g=math.gcd(denominator_N,numerator_N)
        return Fraction(numerator_N//g,denominator_N//g)

    def __sub__(self,other):
        denominator_N=self.denominator*other.denominator
        numerator_N  =-self.denominator*other.numerator + other.denominator*self.numerator
        g=math.gcd(denominator_N,numerator_N)
        return Fraction(numerator_N//g,denominator_N//g)

    def __mul__(self,other):
        denominator_N=self.denominator*other.denominator 
        numerator_N =self.numerator *other.numerator 
        g=math.gcd(denominator_N,numerator_N)
        return Fraction(numerator_N//g,denominator_N//g)

    def __truediv__(self,other):
        denominator_N=self.denominator*other.numerator 
        numerator_N =self.numerator *other.denominator 
        g=math.gcd(denominator_N,numerator_N)
        return Fraction(numerator_N//g,denominator_N//g)

    def __eq__(self,other):
        g=math.gcd(self.denominator,self.numerator)
        o=math.gcd(other.denominator,other.numerator)
        if self.numerator//g == other.numerator//o and self.denominator//g == other.denominator//o:
            return True
        else:
            return False
    def __ne__(self,other):
        g=math.gcd(self.denominator,self.numerator)
        o=math.gcd(other.denominator,other.numerator)
        if self.numerator//g == other.numerator//o and self.denominator//g == other.denominator//o:
            return False
        else:
            return True    
     
    def __str__(self):
        if self.numerator==self.denominator:
            return str('1')
        elif self.numerator==0:
            return (str(self.numerator))
        elif self.denominator==0:
            raise print('EORR') 
        else:
            return(str(self.numerator)+'/'+str(self.denominator))
